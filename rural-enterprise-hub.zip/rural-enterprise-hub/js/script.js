
/* ==============================
   NEW BUSINESS HUB - SCRIPT.JS
================================= */

// Mobile navigation
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", function () {
    const isOpen = navLinks.classList.toggle("active");

    menuToggle.setAttribute("aria-expanded", isOpen);
    menuToggle.textContent = isOpen ? "✕" : "☰";
});

// Close the mobile menu after clicking a navigation link
document.querySelectorAll("#navLinks a").forEach(function (link) {
    link.addEventListener("click", function () {
        navLinks.classList.remove("active");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.textContent = "☰";
    });
});

// Automatically update the footer year
document.getElementById("year").textContent =
    new Date().getFullYear();

// Business enquiry form

/* ===== BUSINESS ENQUIRY FORM ===== */

const businessForm = document.getElementById("businessForm");
const formStatus = document.getElementById("formStatus");

if (businessForm && formStatus) {
    businessForm.addEventListener("submit", function (event) {
        event.preventDefault();

        if (!businessForm.checkValidity()) {
            businessForm.reportValidity();
            return;
        }

        const name = document.getElementById("name").value.trim();
        const phone = document.getElementById("phone").value.trim();
        const email = document.getElementById("email").value.trim();
        const state = document.getElementById("state").value.trim();
        const district = document.getElementById("district").value.trim();
        const mandal = document.getElementById("mandal").value.trim();
        const message = document.getElementById("message").value.trim();

        const selectedRequirements = Array.from(
            businessForm.querySelectorAll(
                'input[name="requirements"]:checked'
            )
        ).map(function (checkbox) {
            return checkbox.value;
        });

        if (selectedRequirements.length === 0) {
            formStatus.textContent =
                "Please select at least one support requirement.";
            return;
        }

        const subject = encodeURIComponent(
            "New Business Hub Enquiry - " + name
        );

        const body = encodeURIComponent(
            "NEW BUSINESS HUB ENQUIRY\n\n" +
            "Name: " + name + "\n" +
            "Mobile: " + phone + "\n" +
            "Email: " + (email || "Not provided") + "\n" +
            "State: " + (state || "Not provided") + "\n" +
            "District: " + (district || "Not provided") + "\n" +
            "Mandal/Town: " + (mandal || "Not provided") + "\n\n" +
            "Support Required:\n" +
            selectedRequirements.map(function (item) {
                return "- " + item;
            }).join("\n") +
            "\n\nAdditional Details:\n" + message
        );

        // Replace this with your actual business email address.
        const businessEmail = "yourbusiness@gmail.com";
        if (businessEmail === "YOUR_EMAIL@example.com") {
            formStatus.textContent =
                "Please add your business email address in script.js before submitting.";
            return;
        }

        formStatus.textContent =
            "Opening your email application...";

        window.location.href =
            "mailto:" + businessEmail +
            "?subject=" + subject +
            "&body=" + body;
    });
}

/* ===== HOME PAGE AUTOMATIC BANNER SLIDER ===== */
document.addEventListener("DOMContentLoaded", function () {
  const slider = document.querySelector(".hero-slider");

  if (!slider) return;

  const slides = slider.querySelectorAll(".hero-slide");
  const dots = slider.querySelectorAll(".slider-dot");
  const prevButton = slider.querySelector(".slider-arrow.prev");
  const nextButton = slider.querySelector(".slider-arrow.next");

  let currentSlide = 0;
  let slideTimer;

  function showSlide(index) {
    currentSlide = (index + slides.length) % slides.length;

    slides.forEach(function (slide, i) {
      slide.classList.toggle("active", i === currentSlide);
    });

    dots.forEach(function (dot, i) {
      dot.classList.toggle("active", i === currentSlide);
    });
  }

  function startSlider() {
    clearInterval(slideTimer);

    slideTimer = setInterval(function () {
      showSlide(currentSlide + 1);
    }, 5000);
  }

  prevButton.addEventListener("click", function () {
    showSlide(currentSlide - 1);
    startSlider();
  });

  nextButton.addEventListener("click", function () {
    showSlide(currentSlide + 1);
    startSlider();
  });

  dots.forEach(function (dot, index) {
    dot.addEventListener("click", function () {
      showSlide(index);
      startSlider();
    });
  });

  showSlide(0);
  startSlider();
});

// More dropdown click toggle
document.addEventListener("DOMContentLoaded", function () {
    const moreBtn = document.querySelector(".more-btn");
    const dropdown = document.querySelector(".dropdown-menu");

    if (moreBtn && dropdown) {
        moreBtn.setAttribute("aria-expanded", "false");

        moreBtn.addEventListener("click", function (event) {
            event.stopPropagation();

            const isOpen = dropdown.classList.toggle("dropdown-open");
            moreBtn.setAttribute("aria-expanded", String(isOpen));
        });

        document.addEventListener("click", function (event) {
            if (!event.target.closest(".nav-dropdown")) {
                dropdown.classList.remove("dropdown-open");
                moreBtn.setAttribute("aria-expanded", "false");
            }
        });

        dropdown.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                dropdown.classList.remove("dropdown-open");
                moreBtn.setAttribute("aria-expanded", "false");
            });
        });
    }
});